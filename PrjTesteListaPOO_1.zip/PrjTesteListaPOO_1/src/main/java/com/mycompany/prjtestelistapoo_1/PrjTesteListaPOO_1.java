/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjtestelistapoo_1;

/**
 *
 * @author iftm
 */
public class PrjTesteListaPOO_1 {

    public static void main(String[] args) {
        ComparacoesListas compL = new ComparacoesListas();
        
        compL.compArrayList_LinkedList();
        System.out.println("");
        System.out.println("**********************");
        compL.comparacaoGeralList();
    }
}
