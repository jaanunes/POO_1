/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjexerciciomoodle;

import com.mycompany.prjexerciciomoodle.menu.Menu;

/**
 *
 * @author janai
 */
public class PrjExercicioMoodle {

    public static void main(String[] args) {
        Menu.mostrarMenu();
    }
}
