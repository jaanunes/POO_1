/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemplolistas.util;

import com.mycompany.prjexemplolistas.objetos.*;
import java.text.NumberFormat;

/**
 *
 * @author iftm
 */
public class MostrarDados 
{
    public void mostrar(Disciplina d)
    {
        System.out.println("Nome: " + d.getNome());
        System.out.println("Periodo: " + d.getPeriodo());
        System.out.println("Carga Horaria: " + d.getCargaHoraria());
        System.out.println("Professor: " + d.getProfessor() .getNome());
        d.getLstAlunos();
        System.out.println("------------------------------------");
        for(Aluno a : d.getLstAlunos())
        {
            System.out.println("Nome: " + a.getNome());
            System.out.println("Data Nascimento: " + a.getDataNasc());
            System.out.println("------------------------------------");
        }
        
    }
    
}
