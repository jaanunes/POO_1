/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjexemplolistas;

import com.mycompany.prjexemplolistas.objetos.Aluno;
import com.mycompany.prjexemplolistas.objetos.Disciplina;
import com.mycompany.prjexemplolistas.objetos.Professor;
import com.mycompany.prjexemplolistas.util.MostrarDados;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author iftm
 */
public class PrjExemploListas {

    public static void main(String[] args) 
    {
        Disciplina disciplina = new Disciplina();
        Aluno aluno = new Aluno();
        Aluno aluno2 = new Aluno();
        Professor professor = new Professor();
        
        professor.setNome("Professor Teste 1");
        professor.setGraduacao("ADS");
        professor.setCfp("111.222.333.-14");
        
        aluno.setNome("Aluno Teste 1");
        aluno.setCpf("333.111.444-55");
        aluno.setDataNasc("01/01/2000");
        
        aluno2.setNome("Aluno Teste 2");
        aluno2.setCpf("222.111.444-55");
        aluno2.setDataNasc("20/10/2000");
        
        List<Aluno> lstAlunos = new ArrayList<Aluno>();
        
        lstAlunos.add(aluno);
        lstAlunos.add(aluno2);
        
        disciplina.setNome("POO I");
        disciplina.setPeriodo(3);
        disciplina.setCargaHoraria(80);
        disciplina.setProfessor(professor);
        disciplina.setLstAlunos(lstAlunos);
        
        MostrarDados md = new MostrarDados();
        md.mostrar(disciplina);
    }
}
