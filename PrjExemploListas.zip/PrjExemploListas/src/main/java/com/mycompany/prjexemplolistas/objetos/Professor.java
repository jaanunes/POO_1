
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemplolistas.objetos;

import java.util.List;

/**
 *
 * @author iftm
 */
public class Professor 
{
    private String nome;
    private String cfp;
    private String graduacao;
    private List<Disciplina> lstDisciplinas;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCfp() {
        return cfp;
    }

    public void setCfp(String cfp) {
        this.cfp = cfp;
    }

    public String getGraduacao() {
        return graduacao;
    }

    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }

    public List<Disciplina> getLstDisciplinas() {
        return lstDisciplinas;
    }

    public void setLstDisciplinas(List<Disciplina> lstDisciplinas) {
        this.lstDisciplinas = lstDisciplinas;
    }
      
    
    
}

