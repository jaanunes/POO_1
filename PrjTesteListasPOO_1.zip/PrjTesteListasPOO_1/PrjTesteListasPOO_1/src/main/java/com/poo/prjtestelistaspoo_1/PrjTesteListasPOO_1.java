/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjtestelistaspoo_1;

/**
 *
 * @author iftm
 */
public class PrjTesteListasPOO_1 {

    public static void main(String[] args) {
        /*ComparacoesListas compL = new ComparacoesListas();
        
        compL.compArrayList_LinkedList();
        System.out.println("");
        System.out.println("******************************");
        compL.comparacaoGeralList();*/
        
        /*Comparacao_List_Set compL_Set = new Comparacao_List_Set();
        compL_Set.funcionamentoList();
        System.out.println("");
        System.out.println("**************");
        compL_Set.funcionamentoSet();*/
        

      

        ComparacaoList_Util_Awt compUtil_AWT = new ComparacaoList_Util_Awt();
        compUtil_AWT.exemploListAWT();

        /*ExemploMaps exMaps = new ExemploMaps();
        exemploMaps.exHashMapSimples();
        System.out.println("");
        System.out.println("****************************");
        exemploMaps.exHashMapComObjetos();*/
    
    }  
}
