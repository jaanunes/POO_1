/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjtestelistaspoo_1;

import java.util.HashMap;
import java.util.Map;


public class ExemploMaps {
    
    public void exHashMapSimples()
    {
        Map<String, Integer> idades = new HashMap<>();
        
        idades.put("Joao", 30);
        idades.put("Maria", 25);
        idades.put("Jose", 35);
        idades.put("Carlos", 40);
        
        System.out.println("Mapa de idades: "+ idades);
        
        int idadePessoal= idades.get("Joao");
        System.out.println("A idade de Joao e: " +idadePessoal);
        
        Integer idadePessoa2 = idades.get("Pedro");
        System.out.println("A idade de pedro e: " +idadePessoa2);
        
        boolean contemKey = idades.containsKey("Maria");
        System.out.println("O Mapa contem a chave 'Maria'? " +contemKey);
        boolean contemIdade = idades.containsValue(40);
        System.out.println("O mapa contem a idade 40? " + contemIdade);
        
        idades.remove("Jose");
        System.out.println("Mapa apos remover Jose: " +idades);
        
        System.out.println("\n Interando sobre as chaves e valores :");
        for (Map.Entry<String, Integer> entry : idades.entrySet()){
            System.out.println("Chave: " + entry.getKey() + "Valor: "+ entry.getValue());
        }
        
    }
    
    public void exHashMapComObjetos(){
        
        Map<String, Funcionario> funcionarios = new HashMap<>();
        
        funcionarios.put("fun001", new Funcionario("Joao", 5000.00));
        funcionarios.put("fun002", new Funcionario("Jose", 6500.00));
        funcionarios.put("fun003", new Funcionario("Maria", 4800.00));
        
        System.out.println("Mapa de funcionarios: "+ funcionarios);
        String idParaBuscar = "fun002";
        Funcionario funcionarioEncontrado = funcionarios.get(idParaBuscar);
        
        if(funcionarioEncontrado != null){
            System.out.println("\nFuncionario encontrado com ID " +idParaBuscar +":");
            System.out.println(funcionarioEncontrado);
        }else{
            System.out.println("\nNenhum funcionario encontrado com Id "+ idParaBuscar);
        }
    }
    
    
}
