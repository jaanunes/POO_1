/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.dao;

import com.mycompany.prjbdfornecedores.models.Produto;
import com.mycompany.prjbdfornecedores.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author janai
 */
public class ProdutoDAO 
{
    Connection conn;
    
    public ProdutoDAO()
    {
        conn = new Conexao().conectar();
    }

    public Produto buscarPorId(int id) 
    {
        Produto p = null;
        ResultSet rs;
        
        try
        {
            PreparedStatement ppStmt = conn.prepareCall("SELECT * FROM produto WHERE idProduto = ?");
            
            ppStmt.setInt(1, id);
            
            rs = ppStmt.executeQuery();
            
            if (rs.next()) {
                p = new Produto();

                p.setIdProduto(rs.getInt("idProduto"));
                p.setNome(rs.getString("nome"));
                p.setValor(rs.getDouble("valor"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return p;
    }
}
