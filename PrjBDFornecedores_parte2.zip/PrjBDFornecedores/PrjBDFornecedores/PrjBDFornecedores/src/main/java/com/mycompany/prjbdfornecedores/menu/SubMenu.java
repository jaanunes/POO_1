/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.menu;

import com.mycompany.prjbdfornecedores.bo.FornecedorBO;
import com.mycompany.prjbdfornecedores.models.Contato;
import com.mycompany.prjbdfornecedores.models.Fornecedor;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author janai
 */
public class SubMenu 
{
    private static Scanner scanner = new Scanner(System.in);
    private static FornecedorBO fornecedorBO = new FornecedorBO();
    
    public static void mostrarSubMenu()
    {
        int opcao;
        do{
            System.out.println("\n--- Menu Fornecedores---");
            System.out.println("1- Cadastrar novo Fornecedor");
            System.out.println("2- Listar todos");
            System.out.println("3- Alterar Fornecedor");
            System.out.println("4- Voltar ao Menu Principal");
            System.out.println("Escolha uma opcao: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) 
            {
                case 1 -> salvarFornecedor();
                case 2 -> listarTodos();
                case 3 -> editarFornecedor();
                case 4 -> System.out.println("Voltando ao menu principal...");

                default -> System.out.print("Opcao invalida. Tente novamente.");
            }
        }while(opcao != 4);
        
        scanner.close();
    }
    
    private static void salvarFornecedor()
    {
        System.out.println("\n --- Cadastro de Veiculo ---");
        Fornecedor fornecedor = new Fornecedor();

        System.out.println("Nome: ");
        fornecedor.setNome(scanner.nextLine());
        System.out.println("CNPJ: ");
        fornecedor.setCnpj(scanner.nextLine());

        String resposta;
        List<Contato> contatos = new LinkedList<>();
        
        do{
            System.out.println("Deseja adicionar um contato para" + fornecedor.getNome() + "? (s/n): ");
            resposta = scanner.nextLine().toLowerCase();
            if(resposta.equals("s")){
                contatos.add(lerDadosContato());
            }
        }while (resposta.equals("s"));
            
            fornecedor.setContatos(contatos);
            fornecedorBO.salvarFornecedor(fornecedor);
    }
    
    private static Contato lerDadosContato()
    {
        System.out.println("\n --- Cadastro de Contato ---");
        Contato contato = new Contato();

        System.out.println("Tipo de contato: ");
        contato.setTipo_contato(scanner.nextLine());
        System.out.println("Contato: ");
        contato.setContato(scanner.nextLine());

        return contato;
    }
    
    private static void editarFornecedor() 
    {
        System.out.print("\nDigite o ID do fornecedor a ser editado: ");
        int id_fornecedor = scanner.nextInt();

        Fornecedor fornecedor = fornecedorBO.buscarFornecedor();
        if (fornecedor == null) {
            System.out.println("Fornecedor não encontrado!");
            return;
        }

        System.out.println("Dados atuais:");
        System.out.println(fornecedor);

        System.out.println("\n--- Informe os novos dados ---");
        System.out.println("Nome: ");
        fornecedor.setNome(scanner.nextLine());
        System.out.println("CNPJ: ");
        fornecedor.setCnpj(scanner.nextLine());

        fornecedorBO.editarFornecedor(fornecedor);
        System.out.println("Fornecedor atualizado com sucesso!");
    }
    
    private static void listarTodos() 
    {
        System.out.println("\n--- Lista de Fornecedores ---");
        List<Fornecedor> fornecedor = fornecedorBO.buscarFornecedor();

        if (fornecedor == null || fornecedor.isEmpty()) {
            System.out.println("Nenhum fornecedor encontrado.");
        } else {
            for (Fornecedor f : fornecedor) {
                System.out.println(f);
            }
        }
    }
}
