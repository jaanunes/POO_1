/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.dao;

import com.mycompany.prjbdfornecedores.models.Contato;
import com.mycompany.prjbdfornecedores.models.Entrada;
import com.mycompany.prjbdfornecedores.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author iftm
 */
public class EntradaDAO 
{
    Connection conn;
    
    public EntradaDAO()
    {
        conn = new Conexao().conectar();
    }
    
    public Entrada salvar(Entrada e){
        try{
            PreparedStatement stmt = conn.prepareStatement
        ("INSERT INTO entrada(data_entrada, id_fornecedor,  id_produto, quantidade, total_entrada) values (?,?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, e.getData_entrada());
            stmt.setInt(2, e.getFornecedor().getId_fornecedor());
            stmt.setInt(3, e.getProduto().getIdProduto());
            stmt.setInt(4, e.getQuantidade());
            stmt.setDouble(5, e.getTotal_entrada());

            int verif = stmt.executeUpdate();
            
            if(verif > 0){
                ResultSet rs_id = stmt.getGeneratedKeys();
                if(rs_id.next()){
                    e.setIdEntrada(rs_id.getInt(1));
                }
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return e;
    }

    public List<Entrada> ListEntrada() {

        List<Entrada> lista = new ArrayList<>();
        ResultSet rs;
        
        try
        {
            PreparedStatement ppStmt = conn.prepareCall("SELECT * FROM Entrada");
            
            rs = ppStmt.executeQuery();

            while (rs.next()) 
            {
                Entrada e = new Entrada();

                e.setIdEntrada(rs.getInt("idEntrada"));
                e.setData_entrada(rs.getString("data_entrada"));
                e.setQuantidade(rs.getInt("quantidade"));
                e.setTotal_entrada(rs.getDouble("total_entrada"));

                lista.add(e);
            }
        } catch (SQLException ex) 
        {
            ex.printStackTrace();
        }
        return lista;
    }
    
}
