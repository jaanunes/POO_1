/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.bo;

import com.mycompany.prjbdfornecedores.dao.ProdutoDAO;
import com.mycompany.prjbdfornecedores.models.Produto;

/**
 *
 * @author janai
 */
public class ProdutoBO 
{
     private ProdutoDAO pDAO = new ProdutoDAO();

    public Produto buscarPorId(int id) 
    {
        return pDAO.buscarPorId(id);
    }
}
