/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.menu;

import com.mycompany.prjbdfornecedores.bo.EntradaBO;
import com.mycompany.prjbdfornecedores.bo.FornecedorBO;
import com.mycompany.prjbdfornecedores.bo.ProdutoBO;
import com.mycompany.prjbdfornecedores.models.Entrada;
import com.mycompany.prjbdfornecedores.models.Fornecedor;
import com.mycompany.prjbdfornecedores.models.Produto;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author iftm
 */
public class Menu 
{
    private static Scanner scanner = new Scanner(System.in);
    private static EntradaBO entradaBO = new EntradaBO();
    private FornecedorBO fornecedorBO = new FornecedorBO();
    private ProdutoBO produtoBO = new ProdutoBO();

    public void iniciar() {

        int opcao = 0;

        do {
            System.out.println("\n===== MENU PRINCIPAL =====");
            System.out.println("1. Gerenciar Fornecedores");
            System.out.println("2. Registrar Nova Entrada (Compra)");
            System.out.println("3. Visualizar Entradas");
            System.out.println("4. Sair");
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();

            switch (opcao) {

                case 1:
                    SubMenu.mostrarSubMenu();
                    break;

                case 2:
                    registrarEntrada();
                    break;
                    
                case 3:
                    listarEntradas();
                    break;

                case 4:
                    System.out.println("Saindo do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 4);
    }

    private void registrarEntrada() {

        System.out.println("\n--- REGISTRAR NOVA ENTRADA ---");

        System.out.print("Informe o ID do Fornecedor: ");
        int id_Fornecedor = scanner.nextInt();

        System.out.print("Informe o ID do Produto: ");
        int idProduto = scanner.nextInt();

        System.out.print("Informe a quantidade: ");
        int qtd = scanner.nextInt();

        Produto prod = produtoBO.buscarPorId(idProduto);
        Fornecedor forn = fornecedorBO.buscarPorId(id_Fornecedor);

        if (prod == null) {
            System.out.println("Produto não encontrado!");
            return;
        }

        if (forn == null) {
            System.out.println("Fornecedor não encontrado!");
            return;
        }

        Entrada entrada = new Entrada();
        entrada.setFornecedor(forn);
        entrada.setProduto(prod);
        entrada.setQuantidade(qtd);

        // data automática
        entrada.setData_entrada(java.time.LocalDate.now().toString());

        // total da compra
        entrada.setTotal_entrada(prod.getValor() * qtd);

        entradaBO.salvar(entrada);

        System.out.println("Entrada registrada com sucesso!");
        System.out.println("Total da compra: R$ " + entrada.getTotal_entrada());
    }


    private void listarEntradas() {

        System.out.println("\n--- LISTA DE ENTRADAS ---");

        var lista = entradaBO.listarEntrada();

        if (lista.isEmpty()) {
            System.out.println("Nenhuma entrada registrada.");
            return;
        }

        for (Entrada e : lista) {
            System.out.println(
                "ID: " + e.getIdEntrada() +
                " | Data: " + e.getData_entrada() +
                " | Fornecedor: " + e.getFornecedor().getNome() +
                " | Produto: " + e.getProduto().getNome() +
                " | Qtd: " + e.getQuantidade() +
                " | Total: R$" + e.getTotal_entrada()
            );
        }
    }
    
}
