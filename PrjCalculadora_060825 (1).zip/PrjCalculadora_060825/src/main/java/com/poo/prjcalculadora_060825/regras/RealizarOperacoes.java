/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjcalculadora_060825.regras;

/**
 *
 * @author clc
 */
public class RealizarOperacoes 
{
    public float adicao(float nro1, float nro2)
    {
        return nro1 + nro2;
    }
    
    public float subtracao(float nro1, float nro2)
    {
        return nro1 - nro2;
    }
    
    public float multiplicacao(float nro1, float nro2)
    {
        return nro1 * nro2;
    }
    
    public float divisao(float nro1, float nro2)
    {
        return nro1 / nro2;
    }    
}
