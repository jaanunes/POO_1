/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjcalculadora_060825;

import com.poo.prjcalculadora_060825.menus.MenuPrincipal;

/**
 *
 * @author clc
 */
public class PrjCalculadora_060825 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        /*RealizarOperacoes ro = new RealizarOperacoes();
        
        System.out.println(ro.adicao(20, 4));
        System.out.println(ro.subtracao(20, 4));
        System.out.println(ro.multiplicacao(20, 4));
        System.out.println(ro.divisao(20, 4));*/
        
        /*DadosEntrada de = new DadosEntrada();
        
        de.setA(1);
        de.setB(5);
        de.setC(6);
        
        RealizarCalculoEqSegGrau calcEqSegGrau = new RealizarCalculoEqSegGrau();
        calcEqSegGrau.realizarCalculo(de);*/
        
        MenuPrincipal.menuPrincipal();        
    }
}
