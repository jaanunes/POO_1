/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjcalculadora_060825.objetos;

/**
 *
 * @author clc
 */
public class DadosSaida 
{
    private float delta;
    private float x1L;
    private float x2L;
    private float xV;
    private float yV;

    public float getDelta() {
        return delta;
    }

    public void setDelta(float delta) {
        this.delta = delta;
    }

    public float getX1L() {
        return x1L;
    }

    public void setX1L(float x1L) {
        this.x1L = x1L;
    }

    public float getX2L() {
        return x2L;
    }

    public void setX2L(float x2L) {
        this.x2L = x2L;
    }

    public float getxV() {
        return xV;
    }

    public void setxV(float xV) {
        this.xV = xV;
    }

    public float getyV() {
        return yV;
    }

    public void setyV(float yV) {
        this.yV = yV;
    }
    
}
