/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jogorpg.models;

/**
 *
 * @author janai
 */
public abstract class Personagem 
{
    private String nome;
    private int pontosDeVida;
    
    public Personagem(String nome, int pontosDeVida)
    {
        this.nome = nome;
        this.pontosDeVida = pontosDeVida;
    }
    
    public void receberDano(int dano)
    {
        pontosDeVida -= dano;
        if(pontosDeVida < 0){
            pontosDeVida = 0;
        }
        System.out.println(nome +" recebeu " + dano + " de dano. Vida atual: " + pontosDeVida);
    }
    
    public abstract void atacar();
   
}
