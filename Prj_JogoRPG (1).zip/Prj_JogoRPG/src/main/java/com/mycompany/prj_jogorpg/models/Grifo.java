/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jogorpg.models;

import com.mycompany.prj_jogorpg.interfaces.CombateCorpoACorpo;

/**
 *
 * @author janai
 */
public class Grifo extends Personagem implements CombateCorpoACorpo
{
    public Grifo(String nome, int pontosDeVida)
    {
        super(nome,pontosDeVida);
    }
    
     @Override
    public void usarArma() {
        System.out.println("O Grifo golpeia com suas garras afiadas!");
    }

    public void voar() {
        System.out.println("O grifo alça voo majestosamente pelos céus!");
    }

    @Override
    public void atacar() {
        System.out.println("O grifo realiza uma Investida Aérea!");
        usarArma();
    }

}
