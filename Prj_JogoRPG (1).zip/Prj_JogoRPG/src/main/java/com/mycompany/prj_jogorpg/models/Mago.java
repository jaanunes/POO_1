/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jogorpg.models;

import com.mycompany.prj_jogorpg.interfaces.Magia;

/**
 *
 * @author janai
 */
public class Mago extends Personagem implements Magia
{    
    public Mago(String nome, int pontosDeVida)
    {
        super(nome,pontosDeVida);
    }
    
    @Override
    public void lancarFeitico()
    {
        System.out.println("O mago lanca uma bola de fogo!");
    }
    
    @Override
    public void atacar()
    {
        lancarFeitico();
    }
}
