/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prj_jogorpg;

/**
 *
 * @author janai
 */
public class Prj_JogoRPG {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
