/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemploclasseabstrata.models;

/**
 *
 * @author iftm
 */
public class Circulo extends FormaGeometrica
{
    private double raio;
    public Circulo(String nome, double raio)
    {
        super(nome);
        this.raio = raio;
    }
    
    @Override
    public double calcularArea()
    {
        return Math.PI * raio * raio;
    }
}
