/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemploclasseabstrata.models;

/**
 *
 * @author iftm
 */
public class Retangulo extends FormaGeometrica
{
    private double largura;
    private double altura;
    
    public Retangulo (String nome, double largura, double altura)
    {
        super(nome);
        this.largura = largura;
        this.altura = altura;
    }

    @Override
    public double calcularArea()
    {
        return largura * altura;
    }
    
}
