/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjexemploclasseabstrata;

import com.mycompany.prjexemploclasseabstrata.models.Circulo;
import com.mycompany.prjexemploclasseabstrata.models.FormaGeometrica;
import com.mycompany.prjexemploclasseabstrata.models.Retangulo;

/**
 *
 * @author iftm
 */
public class PrjExemploClasseAbstrata 
{
    public static void main(String[] args) 
    {
        FormaGeometrica r = new Retangulo("Retangulo Azul", 10,5);
    
        FormaGeometrica c = new Circulo("Circulo Verde", 7);

        System.out.println("Nome da forma: " + r.getNome());
        System.out.println("Area: " + r.calcularArea());
        
        System.out.println("---");
        
        System.out.println("Nome da forma: " + c.getNome());
        System.out.println("Area: "+ c.calcularArea());
    }
    
    

    
}
