/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.veiculos_conexao;

/**
 *
 * @author janai
 */
public class Veiculos_Conexao {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
