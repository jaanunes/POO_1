/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.veiculos_conexao.dao;

import com.mycompany.veiculos_conexao.models.Veiculo;
import com.mycompany.veiculos_conexao.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author janai
 */
public class VeiculoDAO 
{
    Connection conn;
    
    public VeiculoDAO()
    {
        conn = new Conexao().conectar();
    }
    
    public Veiculo salvar(Veiculo v)
    {
        try{
            PreparedStatement stmt = conn.prepareStatement
            ("INSERT INTO Veiculo(nome, modelo, marca, ano, placa) values (?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, v.getNome());
            stmt.setString(2, v.getModelo());
            stmt.setString(3, v.getMarca());
            stmt.setInt(4, v.getAno());
            stmt.setString(5, v.getPlaca());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                int idGerado = rs.getInt(1);
                v.setIdveiculo(idGerado);
            }
            else{
                v.setIdveiculo(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return v;  
    }
    
    public void editar(Veiculo v)
    {
        try{
            PreparedStatement stmt = conn.prepareStatement
            ("UPDATE veiculo SET nome = ?, modelo = ?, marca = ?, ano = ?, placa = ?"
                    + "WHERE idpessoa = ?");
            stmt.setString(2, v.getModelo());
            stmt.setString(3, v.getMarca());
            stmt.setInt(4, v.getAno());
            stmt.setString(5, v.getPlaca());
            stmt.setInt(6, v.getIdveiculo());
            stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
        
    public int excluir(Veiculo v)
    {
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement
        ("DELETE FROM Veiculo WHERE idveiculo = ?");
            stmt.setInt(1, v.getIdveiculo());
            verif = stmt.executeUpdate();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Veiculo> buscarVeiculo()
    {
        List<Veiculo> lstV = new ArrayList<>();
        
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareCall
        ("SELECT * FROM Veiculo");
            
            rs = ppStmt.executeQuery();
            
            while(rs.next())
            {
                lstV.add(getVeiculo(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstV;
    }
    
    public Veiculo buscarVeiculo(int idveiculo)
    {
        Veiculo v = new Veiculo();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement
            ("SELECT * FROM veiculo WHERE idveiculo = ?", 
                   ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ppStmt.setInt(1, idveiculo);
            rs = ppStmt.executeQuery();
            rs.first();
            v = getVeiculo(rs);
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
        }
        return v;
    }
    
    public List<Veiculo> buscarVeiculo(String nome){
        List<Veiculo> lstV = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement
            ("SELECT * FROM Veiculo WHERE ILIKE ?");
            ppStmt.setString(1, nome+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstV.add(getVeiculo(rs));
            }
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
        }
        return lstV;
    }
    
    public Veiculo getVeiculo(ResultSet rs) throws SQLException
    {
        Veiculo v = new Veiculo();
        
        v.setIdveiculo(rs.getInt("idveiculo"));
        v.setNome(rs.getString("nome"));
        v.setModelo(rs.getString("modelo"));
        v.setMarca(rs.getString("marca"));
        v.setAno(rs.getInt("ano"));
        v.setPlaca(rs.getString("placa"));
        
        return v;
    } 
}
