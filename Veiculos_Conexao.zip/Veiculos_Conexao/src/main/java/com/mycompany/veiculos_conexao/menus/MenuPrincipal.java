/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.veiculos_conexao.menus;

import com.mycompany.veiculos_conexao.bo.VeiculoBO;
import com.mycompany.veiculos_conexao.models.Veiculo;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author janai
 */
public class MenuPrincipal 
{
    private static Scanner scanner = new Scanner(System.in);
    private static VeiculoBO veiculoBO = new VeiculoBO();
    
    public static void mostrarMenu()
    {
        int opcao;
        do{
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1- Salvar Veiculo");
            System.out.println("2- Editar Veiculo");
            System.out.println("3- Excluir Veiculo");
            System.out.println("4- Listar todos Veiculos");
            System.out.println("5- Listar Veiculos, Por ID");
            System.out.println("6- Sair");
            System.out.println("Escolha uma opcao: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) 
            {
                case 1 -> salvarVeiculo();
                case 2 -> editarVeiculo();
                case 3 -> excluirVeiculo();
                case 4 -> listarTodos();
                case 5 -> buscarPorId();
                case 6 -> 
                {
                    System.out.println("Encerrando o programa...");
                    System.exit(0);
                }
                default -> System.out.print("Opcao invalida. Tente novamente.");
            }
        }while(opcao != 6);
        
        scanner.close();
    }
    
    private static void salvarVeiculo()
    {
        System.out.println("\n --- Cadastro de Veiculo ---");
        Veiculo veiculo = new Veiculo();

        System.out.println("Nome: ");
        veiculo.setNome(scanner.nextLine());
        System.out.println("Marca: ");
        veiculo.setMarca(scanner.nextLine());
        System.out.println("Modelo: ");
        veiculo.setModelo(scanner.nextLine());
        System.out.println("Placa: ");
        veiculo.setPlaca(scanner.nextLine());
        System.out.println("Ano: ");
        veiculo.setAno(scanner.nextInt());
        scanner.nextLine();
            
        veiculoBO.salvarVeiculo(veiculo);
        System.out.println("Veículo salvo com sucesso!");
    }

    private static void editarVeiculo() 
    {
        System.out.print("\nDigite o ID do veículo a ser editado: ");
        Int idveiculo = scanner.nextLine();

        Veiculo veiculo = veiculoBO.buscarVeiculo(idveiculo);
        if (veiculo == null) {
            System.out.println("Veículo não encontrado!");
            return;
        }

        System.out.println("Dados atuais:");
        System.out.println(veiculo);

        System.out.println("\n--- Informe os novos dados ---");
        System.out.print("Nome: ");
        veiculo.setNome(scanner.nextLine());
        System.out.print("Marca: ");
        veiculo.setMarca(scanner.nextLine());
        System.out.print("Modelo: ");
        veiculo.setModelo(scanner.nextLine());
        System.out.print("Placa: ");
        veiculo.setPlaca(scanner.nextLine());
        System.out.print("Ano: ");
        veiculo.setAno(scanner.nextInt());
        scanner.nextLine();

        veiculoBO.editarVeiculo(veiculo);
        System.out.println("Veículo atualizado com sucesso!");
    }

    private static void excluirVeiculo() 
    {
        System.out.print("\nDigite o ID do veículo a ser excluído: ");
        Int idveiculo = scanner.nextLine();

        veiculoBO.excluirVeiculo(idveiculo);
        System.out.println("Veículo excluído (se existia).");
    }

    private static void listarTodos() 
    {
        System.out.println("\n--- Lista de Veículos ---");
        List<Veiculo> veiculos = veiculoBO.buscarVeiculo();

        if (veiculos == null || veiculos.isEmpty()) {
            System.out.println("Nenhum veículo encontrado.");
        } else {
            for (Veiculo v : veiculos) {
                System.out.println(v);
            }
        }
    }

    private static void buscarPorId() 
    {
        System.out.print("\nDigite o ID do veículo: ");
        Int idveiculo = scanner.nextLine();

        Veiculo veiculo = veiculoBO.buscarVeiculo(idveiculo);
        if (veiculo != null) {
            System.out.println("\nVeículo encontrado:");
            System.out.println(veiculo);
        } else {
            System.out.println("Nenhum veículo com esse ID.");
        }
    }
}
    

