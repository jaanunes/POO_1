/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.veiculos_conexao.bo;

import com.mycompany.veiculos_conexao.dao.VeiculoDAO;
import com.mycompany.veiculos_conexao.models.Veiculo;
import java.util.List;

/**
 *
 * @author janai
 */
public class VeiculoBO 
{
    VeiculoDAO vDAO;
    
    public VeiculoBO()
    {
        vDAO = new VeiculoDAO();
    }
    
    public void salvarVeiculo(Veiculo v)
    {
        if(v.getPlaca().trim().length() == 7)
        {
            vDAO.salvar(v);
        }else{
            System.err.println("A placa deve ter exatamente 7 caracteres.");
        }
    }
    
    public void editarVeiculo(Veiculo v)
    {
        if(v.getPlaca().trim().length() == 7)
        {
            vDAO.editar(v);
        }else{
            System.err.println("A placa deve ter exatamente 7 caracteres.");
        }
    }
    
    public void excluirVeiculo(Veiculo v)
    {
        vDAO.excluir(v);
    }
    
    public List<Veiculo> buscarVeiculo()
    {
        return vDAO.buscarVeiculo();
    }
    
    public Veiculo buscarVeiculo(int idveiculo)
    {
        return vDAO.buscarVeiculo(idveiculo);
    }
    
    public void mostrarDados(List<Veiculo> lstV)
    {
        if(lstV.isEmpty())
        {
            System.out.println("Nenhum veiculo cadastrado.");
            return;
        }
        for (Veiculo v : lstV)
        {
            printDadosVeiculo(v);
            System.out.println
        ("*************************************");
        }
    }
    
    public void mostrarDados(Veiculo v)
    {
        if(v == null)
        {
            System.out.println("Nenhum veiculo cadastrado.");
            return;
        }
        printDadosVeiculo(v);
        System.out.println
        ("****************************************");
    }
    
    private void printDadosVeiculo(Veiculo v)
    {
        System.out.println("ID: "+ v.getIdveiculo());
        System.out.println("Nome: "+ v.getNome());
        System.out.println("Modelo: "+ v.getModelo());
        System.out.println("Marca: "+ v.getMarca());
        System.out.println("Ano: "+ v.getAno());
        System.out.println("Placa: "+ v.getPlaca());
    }
    
}
