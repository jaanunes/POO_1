/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjbdfornecedores;

import com.mycompany.prjbdfornecedores.bo.FornecedorBO;
import com.mycompany.prjbdfornecedores.models.Contato;
import com.mycompany.prjbdfornecedores.models.Fornecedor;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author janai
 */
public class PrjBDFornecedores {

    public static void main(String[] args) 
    {
        Fornecedor f1 = new Fornecedor();
        f1.setNome("Teste");
        f1.setCnpj("1234567891234");
        
        Fornecedor f2 = new Fornecedor();
        f2.setNome("Teste 2");
        f2.setCnpj("1234567894567");
        
        Contato c1 = new Contato();
        Contato c2 = new Contato();
        
        c1.setTipo_contato("E-mail");
        c1.setContato("teste@teste.com");
        
        c2.setTipo_contato("Celular");
        c2.setContato("34999775566");
        
        List<Contato> lstC = new ArrayList<>();
        lstC.add(c1);
        lstC.add(c2);
        
        f2.setContatos(lstC);
        c1.setFornecedor(f2);
        c2.setFornecedor(f2);
        
        FornecedorBO fBO = new FornecedorBO();
        fBO.salvarFornecedor(f1);
        fBO.salvarFornecedor(f2);
        
    }
}
