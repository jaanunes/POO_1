/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.dao;

import com.mycompany.prjbdfornecedores.models.Contato;
import com.mycompany.prjbdfornecedores.models.Entrada;
import com.mycompany.prjbdfornecedores.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author iftm
 */
public class EntradaDAO 
{
    Connection conn;
    
    public EntradaDAO()
    {
        conn = new Conexao().conectar();
    }
    
    public Entrada salvar(Entrada e){
        try{
            PreparedStatement stmt = conn.prepareStatement
        ("INSERT INTO entrada(data_entrada, id_fornecedor, total_entrada) values (?,?,?)",
                Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, e.getData_entrada());
            stmt.setInt(2, e.getFornecedor().getId_fornecedor());
            stmt.setDouble(3, e.getTotal_entrada());
            int verif = stmt.executeUpdate();
            
            if(verif > 0){
                ResultSet rs_id = stmt.getGeneratedKeys();
                if(rs_id.next()){
                    e.setIdEntrada(rs_id.getInt(1));
                }
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return e;
    }
    
}
