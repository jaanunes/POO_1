/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjbdfornecedores.bo;

import com.mycompany.prjbdfornecedores.dao.EntradaDAO;
import com.mycompany.prjbdfornecedores.models.Entrada;

/**
 *
 * @author iftm
 */
public class EntradaBO 
{
    EntradaDAO eDAO;
    public EntradaBO()
    {
        eDAO = new EntradaDAO();
    }
    
    public void salvarFornecedor(Entrada e)
    {
        eDAO.salvar(e);
    }
    
}
