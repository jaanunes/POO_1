/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemplointerface.models;

/**
 *
 * @author iftm
 */
public class Cliente implements Autenticavel
{
    private String email;
    private String senhaAcesso;
    
    public Cliente(String email, String senha)
    {
        this.email = email;
        this.senhaAcesso = senha;
    }
    
    public boolean autenticar(String senha)
    {
        if(this.senhaAcesso.equals(senha))
        {
            System.out.println("Cliente: "+ this.email + "autenticado com sucesso");
            return true;
        }
        System.out.println("Falha na autenticacao do Cliente "+ this.email + ".");
        return false;
    }
    
}
