/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemplointerface.models;

/**
 *
 * @author iftm
 */
public class Gerente implements Autenticavel
{
    private String login;
    private String senhaSalva;
    
    public Gerente(String login, String senha){
        this.login = login;
        this.senhaSalva = senha;
    }
    
    public boolean autenticar(String senha){
        if(this.senhaSalva.equals(senha)){
            System.out.println("Gerente "+ this.login + "autenticado com sucesso!");
            return true;
        }
        System.out.println("Falha na autenticacao do Gerente "+ this.login + ".");
        return false;
    }
}
