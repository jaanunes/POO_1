/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjexemploconexao;

import com.mycompany.prjexemploconexao.dao.PessoaDAO;
import com.mycompany.prjexemploconexao.models.Pessoa;

/**
 *
 * @author janai
 */
public class PrjExemploConexao {

    public static void main(String[] args) {
        PessoaDAO pDAO = new PessoaDAO();
        
        Pessoa p1 = new Pessoa();
        p1.setNome("Pessoa 1");
        p1.setData("01/01/2000");
        
        Pessoa p2 = new Pessoa();
        p2.setNome("Pessoa 2");
        p2.setData("02/02/2001");
        
        pDAO.salvar(p1);     
    }
}
