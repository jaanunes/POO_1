/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_exerciciobanco.models;

import com.mycompany.prj_exerciciobanco.models.Conta;

/**
 *
 * @author janai
 */
public class ContaCorrente extends Conta
{
    private double TaxaSaque;
    
    public ContaCorrente(String agencia, String numero, double TaxaSaque)
    {
        super(agencia,numero);
        this.TaxaSaque = TaxaSaque;
    }
    
    @Override
    public void sacar(double valor)
    {
        double total = valor + TaxaSaque;
        this.saldo -= total;
    }
    
}