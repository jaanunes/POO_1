/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prj_exerciciobanco;

import com.mycompany.prj_exerciciobanco.models.Conta;
import com.mycompany.prj_exerciciobanco.models.ContaCorrente;
import com.mycompany.prj_exerciciobanco.models.ContaPoupanca;

/**
 *
 * @author janai
 */
public class Prj_ExercicioBanco {

    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente("001", "12345-6",0.50);
        
        System.out.println("### Conta Corrente ###");
        cc.depositar(100.0);
        System.out.println("Deposito de R$100,00 realizado.");
        System.out.println("Saldo atual: R$ "+ cc.getSaldo());
        
        double saque1 = 50.0;
        cc.sacar(saque1);
        System.out.println("\nSaque de R$" + saque1 + 
                " realizado (com taxa de R$0,50).");
        System.out.println("Saldo atual: R$"+ cc.getSaldo());
        
        double saque2 = 60.0;
        cc.sacar(saque1);
        System.out.println("\nSaque de R$" + saque2 + 
                " realizado (com taxa de R$0,50).");
        System.out.println("Saldo atual: R$"+ cc.getSaldo());
        
        System.out.println("\n*******************\n");
        
        ContaPoupanca cp = new ContaPoupanca("002", "34567-8");
        
        System.out.println("### Conta Poupanca ###");
        cp.depositar(100.0);
        System.out.println("Deposito de R$100,00 realizado.");
        System.out.println("Saldo atual: R$ "+ cp.getSaldo());
        
        double saque3 = 50.0;
        cp.sacar(saque3);
        System.out.println("\nSaque de R$" + saque3 + " realizado");
        System.out.println("Saldo atual: R$"+ cp.getSaldo());
        
        double saque4 = 60.0;
        cp.sacar(saque4); 
        System.out.println("Saldo atual: R$"+ cp.getSaldo());
        
        cp.render();
        System.out.println("\nSaldo atual com rendimento: R$"+ cp.getSaldo());
        
        
    }
}
