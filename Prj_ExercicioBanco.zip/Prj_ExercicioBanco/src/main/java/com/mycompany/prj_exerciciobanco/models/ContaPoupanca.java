/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_exerciciobanco.models;

/**
 *
 * @author janai
 */
public class ContaPoupanca extends Conta
{
    private double rendimento = 0.005;
    
    public ContaPoupanca(String agencia, String numero)
    {
        super(agencia, numero);
    }
    
    @Override
    public void sacar(double valor)
    {
        if(saldo >= valor)
        {
            saldo -= valor;
        }else {
            System.out.println("Saldo insuficiente!");
        }
    }
    
        public void render()
    {
        saldo += saldo*rendimento;
    }
    
}
