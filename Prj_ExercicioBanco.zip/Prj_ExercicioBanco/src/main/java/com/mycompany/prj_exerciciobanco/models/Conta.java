/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_exerciciobanco.models;

/**
 *
 * @author janai
 */
public abstract class Conta 
{
    String agencia;
    String numero;
    double saldo;
    
    public Conta(String agencia, String numero)
    {
        this.agencia = agencia;
        this.numero = numero;
    }
    
    public void depositar(double valor)
    {
        this.saldo += valor;
    }

    public double getSaldo()
    {
        return saldo;
    }

    public abstract void sacar(double valor);
    
}