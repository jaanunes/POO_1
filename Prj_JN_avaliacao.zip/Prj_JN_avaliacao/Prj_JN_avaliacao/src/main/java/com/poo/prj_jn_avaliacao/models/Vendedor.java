/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.models;

/**
 *
 * @author IFTM
 */
public class Vendedor extends Pessoa 
{
    private double taxa_comissao;

    public double getTaxa_comissao() {
        return taxa_comissao;
    }

    public void setTaxa_comissao(double taxa_comissao) {
        this.taxa_comissao = taxa_comissao;
    }
    
}
