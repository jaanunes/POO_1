/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.bo;

import com.poo.prj_jn_avaliacao.dao.EmpresaDAO;
import com.poo.prj_jn_avaliacao.models.Associado;
import com.poo.prj_jn_avaliacao.models.Empresa;
import com.poo.prj_jn_avaliacao.models.Pessoa;
import com.poo.prj_jn_avaliacao.models.Vendedor;
import java.util.List;

/**
 *
 * @author IFTM
 */
public class EmpresaBO 
{
    EmpresaDAO eDAO;
    
    public EmpresaBO()
    {
        eDAO = new EmpresaDAO();
    }
    
    public void salvarEmpresa(Empresa e)
    {
        if(e.getCnpj().trim().length() == 18)
        {
            eDAO.salvarEmpresa(e);
        }else{
            System.err.println("CNPJ incorreto!");
        }
    }
    
    public List<Empresa> buscarEmpresa()
    {
        return eDAO.buscarEmpresa();
    }
    
    public Empresa buscarEmpresa(String cnpj)
    {
        return eDAO.buscarEmpresa(cnpj);
    }
    
    public void mostrarDados(List<Empresa> lstE)
    {
        if(lstE.isEmpty())
        {
            System.out.println("Nenhuma empresa cadastrada.");
            return;
        }
        for (Empresa e : lstE)
        {
            printDadosEmpresa(e);
            System.out.println
        ("*************************************");
            for (Pessoa p: e.getLstPessoas()){
                printDadosPessoa(p);
                System.out.println("---------------------");
            }
        }
    }
    
    public void mostrarDados(Empresa e)
    {
        if(e == null){
            System.out.println("Nenhuma empresa cadastrada.");
            return;
        }
        printDadosEmpresa(e);
        System.out.println
        ("****************************************");

        if(!e.getLstPessoas().isEmpty())
        {   
            for(Pessoa p : e.getLstPessoas()){
            printDadosPessoa(p);
            System.out.println("-----------------");
            }
        }
    }
    
    private void printDadosEmpresa(Empresa e)
    {
        System.out.println("Nome: " + e.getNome());
        System.out.println("CNPJ: " + e.getCnpj());
    }
    
    private void printDadosPessoa(Pessoa pessoa) {
        System.out.println("  Nome: " + pessoa.getNome());
        System.out.println("  CPF: " + pessoa.getCpf());
        System.out.println("  Data de Nascimento: " + pessoa.getData_nascimento());
        
        
        if (pessoa instanceof Vendedor) {
            Vendedor vendedor = (Vendedor) pessoa;
            System.out.println("  Tipo: Vendedor");
            System.out.println("  Taxa de Comissão: " + vendedor.getTaxa_comissao() + "%");
        } else if (pessoa instanceof Associado) {
            Associado associado = (Associado) pessoa;
            System.out.println("  Tipo: Associado");
            System.out.println("  Taxa de Participação nos Lucros: " + associado.getTaxaParticipacaoLucros() + "%");
        }
    }
}
