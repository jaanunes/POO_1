/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.models;

/**
 *
 * @author IFTM
 */
public class Associado extends Pessoa
{
    private double taxaParticipacaoLucros;

    public double getTaxaParticipacaoLucros() {
        return taxaParticipacaoLucros;
    }

    public void setTaxaParticipacaoLucros(double taxaParticipacaoLucros) {
        this.taxaParticipacaoLucros = taxaParticipacaoLucros;
    }
}
