/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.models;

import java.util.List;

/**
 *
 * @author IFTM
 */
public class Empresa 
{
    private String nome;
    private String cnpj;
    private List<Pessoa> lstPessoas;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public List<Pessoa> getLstPessoas() {
        return lstPessoas;
    }

    public void setLstPessoas(List<Pessoa> lstPessoas) {
        this.lstPessoas = lstPessoas;
    }
    

    
    
    
}
