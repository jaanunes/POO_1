/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.menu;

import com.poo.prj_jn_avaliacao.bo.EmpresaBO;
import com.poo.prj_jn_avaliacao.models.Associado;
import com.poo.prj_jn_avaliacao.models.Empresa;
import com.poo.prj_jn_avaliacao.models.Pessoa;
import com.poo.prj_jn_avaliacao.models.Vendedor;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/**
 *
 * @author IFTM
 */
public class Menu 
{
    private static Scanner scanner = new Scanner(System.in);
    private static EmpresaBO empresaBO = new EmpresaBO();
    
    public static void mostrarMenu()
    {
        int opcao;
        do{
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1- Salvar nova Empresa");
            System.out.println("2- Listar todas as Empresas e seus Membros");
            System.out.println("3- Listar Empresas e seus Membros, Por CNPJ");
            System.out.println("4- Sair");
            System.out.println("Escolha uma opcao: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao){
                case 1 -> salvarEmpresaComMembros();
                case 2 -> listarEmpresas();
                case 3 -> {
                    System.out.println("Digite o CNPJ:");
                    String cnpj = scanner.nextLine();
                    listarEmpresa(cnpj);
                }
                case 4 -> System.out.print("Saindo do programa...");
                default -> System.out.print("Opcao invalida. Tente novamente.");
            }
        }while(opcao != 4);
        
        scanner.close();
    }
    
    private static void salvarEmpresaComMembros()
    {
        System.out.println("\n--- Cadastro da Empresa ---");
        Empresa empresa = new Empresa();
        
        System.out.println("Nome: ");
        empresa.setNome(scanner.nextLine());
        System.out.println("CNPJ: ");
        empresa.setCnpj(scanner.nextLine());
        
        String resposta;
        List<Pessoa> pessoas = new LinkedList<>();
        
        do{
            System.out.println("Deseja adicionar um novo membro? (s/n): ");
            resposta = scanner.nextLine().toLowerCase();
            if(resposta.equals("s")){
                pessoas.add(lerDadosPessoa());
            }
        }while (resposta.equals("s"));
            
            empresa.setLstPessoas(pessoas);
            empresaBO.salvarEmpresa(empresa);
    }
    
    private static Pessoa lerDadosPessoa()
    {
        System.out.println("\n--- Cadastro do Membro ---");
        System.out.println("Nome: ");
        String nome = scanner.nextLine();
        System.out.println("CPF: ");
        String cpf = scanner.nextLine();
        System.out.println("Data Nascimento: ");
        String data = scanner.nextLine();
        System.out.println("Tipo (vendedor/associado): ");
        String tipo = scanner.nextLine().toLowerCase();

        if (tipo.equals("vendedor")) {
            System.out.println("Taxa de comissão (%): ");
            int taxa = scanner.nextInt();
            scanner.nextLine();
            Vendedor v = new Vendedor();
            v.setNome(nome);
            v.setCpf(cpf);
            v.setData_nascimento(data);
            v.setTaxa_comissao(taxa);
            return v;
        } else if (tipo.equals("associado")) {
            System.out.println("Taxa de participação nos lucros (%): ");
            int taxa = scanner.nextInt();
            scanner.nextLine();
            Associado a = new Associado();
            a.setNome(nome);
            a.setCpf(cpf);
            a.setData_nascimento(data);
            a.setTaxaParticipacaoLucros(taxa);
            return a;
        } else {
            Pessoa p = new Pessoa();
            p.setNome(nome);
            p.setCpf(cpf);
            p.setData_nascimento(data);
            p.setTipo(tipo);
            return p;
        }
    }
    
    private static void listarEmpresas(){
        List<Empresa> empresas = empresaBO.buscarEmpresa();
        if(empresas != null)
            empresaBO.mostrarDados(empresas);
    }

    private static void listarEmpresa(String cnpj){
        Empresa e = empresaBO.buscarEmpresa(cnpj);
        if( e != null)
            empresaBO.mostrarDados(e);
    }
    
}
