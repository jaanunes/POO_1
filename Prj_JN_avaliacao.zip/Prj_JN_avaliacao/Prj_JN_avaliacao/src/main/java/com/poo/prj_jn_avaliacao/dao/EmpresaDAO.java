/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.dao;

import com.poo.prj_jn_avaliacao.models.Associado;
import com.poo.prj_jn_avaliacao.models.Empresa;
import com.poo.prj_jn_avaliacao.models.Pessoa;
import com.poo.prj_jn_avaliacao.models.Vendedor;
import com.poo.prj_jn_avaliacao.util.EscreverArquivo;
import com.poo.prj_jn_avaliacao.util.LerArquivo;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 *
 * @author IFTM
 */
public class EmpresaDAO 
{
    private final String ARQUIVO = "c:\\EmpresaPessoa.txt";
    private final boolean MANTER = true;
    
     public void salvarEmpresa (Empresa e)
    {
        String dados = "" + e.getNome() + ", " + e.getCnpj();
        List<Pessoa> lstPessoas = e.getLstPessoas();
        for (Pessoa pessoa : lstPessoas)
        {
            if (pessoa instanceof Vendedor v) {
                dados += ";" + v.getNome() + ", " + v.getCpf() + ", " + v.getData_nascimento() + ", tipo:vendedor, comissao:" + v.getTaxa_comissao();
            } else if (pessoa instanceof Associado a) {
                dados += ";" + a.getNome() + ", " + a.getCpf() + ", " + a.getData_nascimento() + ", tipo:associado, participacao:" + a.getTaxaParticipacaoLucros();
            }
           
        }
        new EscreverArquivo().escrever(ARQUIVO, dados, MANTER);
    }
     
     public List<Empresa> buscarEmpresa()
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null)
        {
            return null;
        }
        
        List<Empresa> lstE = new ArrayList<>();
        try{
            while (br.ready())
            {
                String itensString[] = br.readLine().split(";");
                
                if(itensString.length != 0)
                {
                    Empresa e = new Empresa();
                    
                    String objEmpresa[] = itensString[0].split(",");
                    e.setNome(objEmpresa[0].trim());
                    e.setCnpj(objEmpresa[1].trim());
                    
                    lstE.add(e);
                    
                    if(itensString.length != 1)
                    {
                        List<Pessoa> lstPessoas = new LinkedList<>();
                        //pula o primeiro item (que é o nome e CNPJ da empresa
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        //leitura dos membros da empresa
                        for (String item : itensString) 
                        {
                            String objPessoa [] = item.split(",");
                            String tipo = "";
                            double taxa = 0;

                            for (String part : objPessoa) {
                                if (part.contains("tipo:")) {
                                    tipo = part.split(":")[1].trim();
                                } else if (part.contains("comissao:") || part.contains("participacao:")) {
                                    taxa = Double.parseDouble(part.split(":")[1].trim());
                                }
                            }

                            Pessoa p;
                            if (tipo.equalsIgnoreCase("vendedor")) {
                                Vendedor v = new Vendedor();
                                v.setNome(objPessoa[0].trim());
                                v.setCpf(objPessoa[1].trim());
                                v.setData_nascimento(objPessoa[2].trim());
                                v.setTaxa_comissao((int) taxa);
                                p = v;
                            } else if (tipo.equalsIgnoreCase("associado")) {
                                Associado a = new Associado();
                                a.setNome(objPessoa[0].trim());
                                a.setCpf(objPessoa[1].trim());
                                a.setData_nascimento(objPessoa[2].trim());
                                a.setTaxaParticipacaoLucros((int) taxa);
                                p = a;
                            } else {
                                Pessoa pessoa = new Pessoa();
                                pessoa.setNome(objPessoa[0].trim());
                                pessoa.setCpf(objPessoa[1].trim());
                                pessoa.setData_nascimento(objPessoa[2].trim());
                                pessoa.setTipo(tipo);
                                p = pessoa;
                            }
                            lstPessoas.add(p);
                        }
                        e.setLstPessoas(lstPessoas);

                    }
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return lstE;   
    }
     
     public Empresa buscarEmpresa (String cnpj)
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null)
        {
            return null;
        }
        Map<String,Empresa> map = new HashMap<>();
        
        try{
            while (br.ready()){
                String itensString[] = br.readLine().split(";");
                
                if(itensString.length != 0)
                {
                    Empresa e = new Empresa();
                    
                    String objEmpresa[] = itensString[0].split(",");
                    e.setNome(objEmpresa[0].trim());
                    e.setCnpj(objEmpresa[1].trim());
                    
                    map.put(e.getCnpj(), e);
                    
                    if(itensString.length != 1)
                    {
                        List<Pessoa> lstPessoas = new LinkedList<>();
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        for (String item : itensString) 
                        {
                            String objPessoa [] = item.split(",");
                            Pessoa p;
                            if(item.contains("comissao"))
                            {
                                Vendedor v = new Vendedor();
                                v.setNome(objPessoa[0].trim());
                                v.setCpf(objPessoa[1].trim());
                                v.setData_nascimento(objPessoa[2].trim());
                                v.setTaxa_comissao(Double.parseDouble(objPessoa[3].split(":")[1].trim()));
                                p = v;                                
                            }
                            else
                            {
                                Associado a = new Associado();
                                 a.setNome(objPessoa[0].trim());
                                 a.setCpf(objPessoa[1].trim());
                                 a.setData_nascimento(objPessoa[2].trim());
                                 a.setTaxaParticipacaoLucros(Double.parseDouble(objPessoa[3].split(":")[1].trim()));
                                 p = a; 
                            }
                            lstPessoas.add(p);
                        }
                        e.setLstPessoas(lstPessoas);

                    }
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return map.get(cnpj);
    }
     
}
