/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.dao;

import com.poo.prj_jn_avaliacao.models.Associado;
import com.poo.prj_jn_avaliacao.models.Empresa;
import com.poo.prj_jn_avaliacao.models.Pessoa;
import com.poo.prj_jn_avaliacao.models.Vendedor;
import com.poo.prj_jn_avaliacao.util.EscreverArquivo;
import com.poo.prj_jn_avaliacao.util.LerArquivo;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 *
 * @author IFTM
 */
public class EmpresaDAO 
{
    private final String ARQUIVO = "c:\\EmpresaPessoa.txt";
    private final boolean MANTER = true;
    
     public void salvarEmpresa (Empresa e)
    {
        String dados = "" + e.getNome() + ", " + e.getCnpj();
        List<Pessoa> lstPessoas = e.getLstPessoa();
        for (Pessoa pessoa : lstPessoas)
        {
            dados = dados + ";" + pessoa.getNome() + ", " + pessoa.getCpf() + ", " + pessoa.getData_nascimento();
        }
        new EscreverArquivo().escrever(ARQUIVO, dados, MANTER);
    }
     
     public List<Empresa> buscarEmpresa()
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null)
        {
            return null;
        }
        
        List<Empresa> lstE = new ArrayList<>();
        try{
            while (br.ready())
            {
                String itensString[] = br.readLine().split(";");
                
                if(itensString.length != 0)
                {
                    Empresa e = new Empresa();
                    
                    String objEmpresa[] = itensString[0].split(",");
                    e.setNome(objEmpresa[0].trim());
                    e.setCnpj(objEmpresa[1].trim());
                    
                    lstE.add(e);
                    
                    if(itensString.length != 1)
                    {
                        List<Pessoa> lstPessoas = new LinkedList<>();
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        for (String item : itensString) 
                        {
                            String objPessoa [] = item.split(",");
                            Pessoa p;
                            if(item.contains("comissao"))
                            {
                                p = new Vendedor(p.setNome(objPessoa[0].trim()), p.setCpf(objPessoa[1].trim()), p.setData_nascimento(objPessoa[2].trim()) , Double.parseDouble(objPessoa[3].split(":")[1].trim()));                                
                            }
                            else
                            {
                                p = new Associado(objPessoa[0], objPessoa[1], objPessoa[2], Double.parseDouble(objPessoa[3].split(":")[1].trim())); 
                            }
                            lstPessoas.add(p);
                        }
                        e.setLstPessoa(lstPessoas);

                    }
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return lstE;   
    }
     
     public Pessoa buscarEmpresa (String Cnpj)
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null)
        {
            return null;
        }
        Map<String,Empresa> map = new HashMap<>();
        
        try{
            while (br.ready()){
                String itensString[] = br.readLine().split(";");
                
                if(itensString.length != 0)
                {
                    Empresa e = new Empresa();
                    
                    String objEmpresa[] = itensString[0].split(",");
                    e.setNome(objEmpresa[0].trim());
                    e.setCnpj(objEmpresa[1].trim());
                    
                    map.put(e.getCnpj(), e);
                    
                    if(itensString.length != 1)
                    {
                        List<Pessoa> lstPessoas = new LinkedList<>();
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        for (String item : itensString) 
                        {
                            String objPessoa [] = item.split(",");
                            Pessoa p;
                            if(item.contains("comissao"))
                            {
                                p = new Vendedor(p.setNome(objPessoa[0].trim()), p.setCpf(objPessoa[1].trim()), p.setData_nascimento(objPessoa[2].trim()) , Double.parseDouble(objPessoa[3].split(":")[1].trim()));                                
                            }
                            else
                            {
                                p = new Associado(objPessoa[0], objPessoa[1], objPessoa[2], Double.parseDouble(objPessoa[3].split(":")[1].trim())); 
                            }
                            lstPessoas.add(p);
                        }
                        e.setLstPessoa(lstPessoas);

                    }
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return map.get(cnpj);
    }
     
}
