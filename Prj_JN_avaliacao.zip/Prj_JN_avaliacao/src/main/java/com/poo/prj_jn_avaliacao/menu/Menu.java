/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prj_jn_avaliacao.menu;

import com.poo.prj_jn_avaliacao.bo.EmpresaBO;
import com.poo.prj_jn_avaliacao.models.Associado;
import com.poo.prj_jn_avaliacao.models.Empresa;
import com.poo.prj_jn_avaliacao.models.Pessoa;
import com.poo.prj_jn_avaliacao.models.Vendedor;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/**
 *
 * @author IFTM
 */
public class Menu 
{
    private static Scanner scanner = new Scanner(System.in);
    private static EmpresaBO empresaBO = new EmpresaBO();
    
    public static void mostrarMenu()
    {
        int opcao;
        do{
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1- Salvar nova Empresa");
            System.out.println("2- Listar todas as Empresas e seus Membros");
            System.out.println("3- Listar Empresas e seus Membros, Por CNPJ");
            System.out.println("4- Sair");
            System.out.println("Escolha uma opcao: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao){
                case 1 -> salvarEmpresaComMembros();
                case 2 -> listarEmpresas();
                case 3 -> {
                    System.out.println("Digite o CNPJ:");
                    String cpf = scanner.nextLine();
                    listarEmpresa(cnpj);
                }
                case 4 -> System.out.print("Saindo do programa...");
                default -> System.out.print("Opcao invalida. Tente novamente.");
            }
        }while(opcao != 4);
        
        scanner.close();
    }
    
    private static void salvarEmpresaComMembros()
    {
        System.out.println("\n--- Cadastro da Empresa ---");
        Empresa empresa = new Empresa();
        
        System.out.println("Nome: ");
        empresa.setNome(scanner.nextLine());
        System.out.println("CNPJ: ");
        empresa.setCnpj(scanner.nextLine());
        
        String resposta;
        List<Pessoa> pessoas = new LinkedList<>();
        
        do{
            System.out.println("Deseja adicionar umm novo membro? (s/n): ");
            resposta = scanner.nextLine().toLowerCase();
            if(resposta.equals("s")){
                pessoas.add(lerDadosPessoa());
            }
        }while (resposta.equals("s"));
            
            empresa.setLstPessoa(pessoas);
            empresaBO.salvarEmpresa(empresa);
    }
    
    private static Pessoa lerDadosPessoa()
    {
        System.out.println("\n --- Cadastro do Membro ---");
        Pessoa pessoa = new Pessoa();
        Vendedor vendedor = new Vendedor();
        Associado associado = new Associado();

        System.out.println("Nome: ");
        pessoa.setNome(scanner.nextLine());
        System.out.println("CPF: ");
        pessoa.setCpf(scanner.nextLine());
        System.out.println("Data Nascimento: ");
        pessoa.setData_nascimento(scanner.nextLine());
        System.out.println("Tipo: ");
        pessoa.setTipo(scanner.nextLine());

        return pessoa;
    }
    
    private static void listarEmpresas(){
        List<Empresa> empresas = empresaBO.buscarEmpresa();
        if(empresas != null)
            empresaBO.mostrarDados(empresas);
    }

    private static void listarEmpresa(String cnpj){
        Empresa e = empresaBO.buscarEmpresa(cnpj);
        if( e != null)
            empresaBO.mostrarDados(e);
    }
    
}
