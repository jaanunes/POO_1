/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_jn_avaliacao;

import com.poo.prj_jn_avaliacao.menu.Menu;

/**
 *
 * @author IFTM
 */
public class Prj_JN_avaliacao {

    public static void main(String[] args) {
       Menu.mostrarMenu();
    }
}
