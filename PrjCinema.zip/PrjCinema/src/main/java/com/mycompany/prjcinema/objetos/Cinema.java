/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcinema.objetos;

import java.util.List;

/**
 *
 * @author iftm
 */
public class Cinema {
    
    private String nome;
    private String endereco;
    private int telefone;
    private List<Filme> lstFilmes_exibicao;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public List<Filme> getLstFilmes_exibicao() {
        return lstFilmes_exibicao;
    }

    public void setLstFilmes_exibicao(List<Filme> lstFilmes_exibicao) {
        this.lstFilmes_exibicao = lstFilmes_exibicao;
    }
    
    
}
