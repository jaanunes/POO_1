/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjcinema.menu;

import java.util.Scanner;

/**
 *
 * @author iftm
 */
public class MenuInicial 
{
    public static void mostrarMenuPrincipal()
    {
        Scanner scanner = new Scanner(System.in);
        int opcao = -1;

        while (opcao != 0){
            System.out.println("====== MENU PRINCIPAL ======");
            System.out.println("1 - Cadastrar Dados");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 -> MenuDadosMoto.opcoesMoto(scanner);
                case 0 -> System.out.println("Encerrando o sistema...");
                default -> System.out.println("Opcao invalida.");
            }
        }
        scanner.close();
    }
    
}
